sap.ui.define([
    "ndbs/ui/vehiclemanagementui/controller/BaseController"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
    function (BaseController) {
        "use strict";

        return BaseController.extend("ndbs.ui.vehiclemanagementui.controller.App", {
            onInit: function () {

            }
        });
    });